#!/bin/bash
# mk.sh <ep> : build timeline + html for an episode
cd "$(dirname "$0")"; python3 build_ep.py $1 && sed "s#<script>#<script src=\"images/manifest.js\"></script><script src=\"ep_$1.js\"></script>\n<script>#" episode_tpl.html | awk 'BEGIN{n=0} /<script src="images\/manifest.js">/{if(n++)sub(/<script src="images\/manifest.js"><\/script><script src="ep_[a-z]+.js"><\/script>/,"")}1' > ep_$1.html
