"""ECHOES score + sound design, synced to ep_<name>.json. Usage: python3 sound_h.py <ep>"""
import sys, json, re, numpy as np, soundfile as sf
from scipy.signal import butter, sosfilt, fftconvolve, resample_poly
name = sys.argv[1]; EP = json.load(open(f"ep_{name}.json"))
SR = 48000; TOTAL = EP["total"]; N = int(TOTAL * SR) + SR; SC = EP["scenes"]; SH = EP["shots"]
rng = np.random.default_rng(11)
T = lambda d: np.arange(int(d * SR)) / SR
lp = lambda x, f, o=2: sosfilt(butter(o, f, "low", fs=SR, output="sos"), x)
hp = lambda x, f, o=2: sosfilt(butter(o, f, "high", fs=SR, output="sos"), x)
bp = lambda x, a, b, o=2: sosfilt(butter(o, [a, b], "band", fs=SR, output="sos"), x)
def env(n, a, d):
    t = np.arange(n) / SR; return np.minimum(1, t / max(a, 1e-4)) * np.exp(-np.maximum(0, t - a) / d)
def put(bus, t0, sig, g=1.0, pan=0.0):
    s = int(t0 * SR)
    if s >= N: return
    if s < 0: sig, s = sig[-s:], 0
    sig = sig[: N - s]; l, r = np.cos((pan + 1) * np.pi / 4) * 1.414, np.sin((pan + 1) * np.pi / 4) * 1.414
    bus[s:s + len(sig), 0] += sig * g * l; bus[s:s + len(sig), 1] += sig * g * r
def reverb(x, secs, mix):
    n = int(secs * SR); t = np.arange(n) / SR; ir = rng.standard_normal((n, 2)) * np.exp(-t / (secs / 5))[:, None]
    ir = np.stack([lp(ir[:, c], 5000) for c in range(2)], 1)
    wet = np.stack([fftconvolve(x[:, c], ir[:, c])[: len(x)] for c in range(2)], 1); wet *= np.max(np.abs(x)) / (np.max(np.abs(wet)) + 1e-9)
    return x * (1 - mix) + wet * mix
def nf(n):
    m = {"C": -9, "C#": -8, "Db": -8, "D": -7, "D#": -6, "Eb": -6, "E": -5, "F": -4, "F#": -3, "G": -2, "G#": -1, "Ab": -1, "A": 0, "A#": 1, "Bb": 1, "B": 2}
    return 440 * 2 ** ((m[n[:-1]] + 12 * (int(n[-1]) - 4)) / 12)
def W(li, key):
    for x in SC[li]["words"]:
        if re.sub(r"[^\w']", "", x["w"]).lower().startswith(key.lower()): return x["t0"]
music = np.zeros((N, 2)); sfx = np.zeros((N, 2)); amb = np.zeros((N, 2))
end_t = SH[-1]["t0"]

# ---------- music ----------
def strings(f, d, g):
    t = T(d); vib = 1 + 0.004 * np.sin(2 * np.pi * 5.2 * t); y = np.zeros_like(t)
    for det in (-0.003, 0, 0.0035):
        ph = 2 * np.pi * np.cumsum(f * (1 + det) * vib) / SR
        for h in range(1, 8): y += np.sin(h * ph + h) / h
    y = lp(y, 900 + 300 * (f > 300)); sw = np.minimum(1, t / (d * 0.35)) * np.minimum(1, (d - t) / (d * 0.3))
    return y * sw * g
def piano(f, d=3.0, g=1.0):
    t = T(d); y = np.zeros_like(t)
    for h, a in ((1, 1), (2, .45), (3, .22), (4, .12), (5, .06)):
        fh = f * h * np.sqrt(1 + 0.0004 * h * h); y += a * np.sin(2 * np.pi * fh * t) * np.exp(-t * (0.9 + h * 0.6))
    return y * env(len(t), 0.004, 10) * g
if name == "taj":
    PADS = [["D2", "A2", "D3", "F3"], ["Bb1", "F2", "D3", "F3"], ["C2", "G2", "Eb3", "G3"], ["A1", "E2", "C#3", "A3"]]
    MOTIF = ["D5", "Eb5", "F#5", "G5", "F#5", "Eb5", "D5", "A4"]
    # tanpura-like drone: plucked D/A cycle with jawari buzz
    t = 0.4
    while t < end_t + 2:
        for j, n in enumerate(["A2", "D3", "D3", "D2"]):
            x = T(2.4); f = nf(n); s = sum(np.sin(2 * np.pi * f * h * x) * (0.6 / h) * (1 + 0.5 * np.sin(2 * np.pi * 0.7 * x * h)) for h in range(1, 12))
            put(music, t + j * 0.55, lp(s, 3500) * env(len(x), 0.01, 1.1), 0.018, (-0.4, 0.2, 0.4, -0.2)[j])
        t += 2.2
else:
    PADS = [["A1", "E2", "A2", "C3"], ["F1", "C2", "A2", "C3"], ["D2", "A2", "D3", "F3"], ["E1", "B1", "G#2", "B2"]]
    MOTIF = ["E5", "C5", "A4", "B4", "C5", "B4", "G#4", "A4"]
cl = 4.8
for i, t0 in enumerate(np.arange(0.2, end_t + 1, cl)):
    for n in PADS[i % 4]: put(music, t0, strings(nf(n), cl + 1.2, 0.022), 1, rng.uniform(-.5, .5))
# piano motif from line 1 onwards, sparse
mt = SC[1]["start"]; k = 0
while mt < end_t - 0.5:
    put(music, mt, piano(nf(MOTIF[k % len(MOTIF)]), 3.2), 0.11, 0.25 * np.sin(k)); mt += 1.2 if k % 4 != 3 else 2.4; k += 1
# timpani on turns (line starts 3 and 5 + their key words)
def timp(f=55, g=1.0):
    x = T(2.5); ff = f * (1 + 0.15 * np.exp(-x / 0.05)); s = np.sin(2 * np.pi * np.cumsum(ff) / SR) * env(len(x), 0.003, 0.9)
    return (s + 0.4 * lp(rng.standard_normal(len(x)), 300) * env(len(x), 0.002, 0.06)) * g
def swell(d=1.6):
    x = T(d); return hp(rng.standard_normal(len(x)), 3000) * (x / d) ** 3 * np.minimum(1, (d - x) / 0.05)
for li in (3, 5):
    put(music, SC[li]["start"] - 0.05, timp(), 0.5); put(sfx, SC[li]["start"] - 1.6, swell(), 0.05)
# ending chord + gong
x = T(5); chord = sum(strings(nf(n), 5, 0.03) for n in PADS[0]); put(music, end_t, chord, 1)
gong = sum(np.sin(2 * np.pi * f * x) * np.exp(-x * dk) for f, dk in ((73, 0.6), (146.7, 0.9), (196, 1.2), (241, 1.5), (311, 2.0))) * env(len(x), 0.005, 9)
put(sfx, end_t + 0.25, lp(gong, 2500), 0.35)

# ---------- SFX helpers ----------
def air_whoosh(d=0.9, g=1.0):
    n = int(d * SR); y = np.zeros(n); a = 0.0; x = rng.standard_normal(n); fc = 200 + 1600 * np.sin(np.pi * np.linspace(0, 1, n)) ** 2
    al = 1 - np.exp(-2 * np.pi * fc / SR)
    for i in range(n): a += al[i] * (x[i] - a); y[i] = a
    return y * np.sin(np.pi * np.linspace(0, 1, n)) ** 2 * g
def key_click():
    x = T(0.06); return (bp(rng.standard_normal(len(x)), 1500, 6000) * env(len(x), 0.0005, 0.008) + 0.5 * np.sin(2 * np.pi * 180 * x) * env(len(x), 0.001, 0.01))
def ding():
    x = T(1.2); return (np.sin(2 * np.pi * 2093 * x) + .4 * np.sin(2 * np.pi * 5230 * x)) * env(len(x), 0.002, 0.25)
def typing(t0, n, dt=0.045):
    for i in range(n): put(sfx, t0 + i * dt + rng.uniform(-.008, .008), key_click(), 0.16 * rng.uniform(.7, 1), rng.uniform(-.3, .3))
def thud(g=1.0):
    x = T(0.5); return (np.sin(2 * np.pi * np.cumsum(60 + 80 * np.exp(-x / 0.02)) / SR) * env(len(x), 0.002, 0.08) + 0.5 * lp(rng.standard_normal(len(x)), 1200) * env(len(x), 0.001, 0.03)) * g
def rustle(d=0.8):
    x = T(d); n = bp(rng.standard_normal(len(x)), 1500, 7000); return n * (0.5 + 0.5 * np.abs(np.sin(2 * np.pi * 9 * x + rng.uniform(0, 3)))) * np.sin(np.pi * x / d)
def shutter():
    a = key_click() * 2; b = np.zeros(int(0.09 * SR)); return np.concatenate([a, b, key_click() * 1.5])
def tick():
    x = T(0.03); return bp(rng.standard_normal(len(x)), 2500, 8000) * env(len(x), 0.0003, 0.004)
def beep(f=700, d=0.08):
    x = T(d); return np.sin(2 * np.pi * f * x) * np.minimum(1, np.minimum(x, d - x) / 0.004)

# ---------- SFX per shot ----------
for i, sh in enumerate(SH):
    t0 = sh["t0"]
    if i > 0: put(sfx, t0 - 0.45, air_whoosh(0.9), 0.10, rng.uniform(-.5, .5))
    if sh.get("stamp"): s = sh["stamp"][0]; typing(t0 + .8, len(s), 1.0 / len(s)); put(sfx, t0 + 1.85, ding(), 0.05)
    if sh["type"] == "arch" and sh.get("mode") == "full": put(sfx, t0 + 0.05, shutter(), 0.25); put(sfx, t0 - 0.2, swell(0.6), 0.04)
    if sh["type"] == "arch" and sh.get("mode") == "framed": put(sfx, t0 + 0.1, thud(), 0.18)
    if sh["type"] == "ill":
        n = sh["n"]
        if n == 2:
            typing(t0 + .6, 24, 1.0 / 24); x = T(sh["t1"] - t0)
            crackle = np.zeros(len(x)); idx = rng.integers(0, len(x), int(len(x) / SR * 14)); crackle[idx] = rng.uniform(.3, 1, len(idx)); put(amb, t0, hp(crackle, 2000) * 0.5, 0.25)
        if n == 4:
            for k in range(int((sh["t1"] - t0) / 0.18)): put(sfx, t0 + 0.1 + k * 0.18, tick(), 0.05 * (1 if k * 0.18 < 3 else 0.4))
            ct = W(2, "Twenty")
            for k in range(28): put(sfx, ct + k * 0.043, tick(), 0.09)
        if n == 5: typing(t0 + .5, 16, 0.9 / 16); x = T(sh["t1"] - t0); put(amb, t0, lp(rng.standard_normal(len(x)), 500) * np.minimum(1, x / 1.5), 0.05)
        if n == 6: put(sfx, t0 + 1.2, ding(), 0.08); put(sfx, t0 + 1.25, thud(), 0.12)
        if n == 10:
            put(sfx, t0 + 0.2, rustle(1.0), 0.18); u = W(0, "useless") - 0.2; x = T(0.9)
            put(sfx, u, bp(rng.standard_normal(len(x)), 2500, 7000) * (0.4 + 0.6 * np.abs(np.sin(2 * np.pi * 6 * x))) * np.sin(np.pi * x / 0.9), 0.07)
        if n == 12:
            tw, y9 = W(2, "twenty"), W(2, "1909")
            for k in range(20): put(sfx, tw - 0.2 + (y9 + 0.2 - tw) * (1 - (1 - k / 20) ** 1.5), tick(), 0.12)
            put(sfx, y9 + 0.2, thud(1.3), 0.4); put(sfx, y9 + 0.2, timp(48), 0.25)
        if n == 13:
            iw = W(4, "intercepted"); x = T(sh["t1"] - t0); stat = bp(rng.standard_normal(len(x)), 800, 4000) * (0.5 + 0.5 * np.sin(2 * np.pi * 0.3 * x))
            put(amb, t0, stat, 0.025)
            m = "−·−· ·− ···· ·  ·· −· − · ·−· −·−· · ·−−· − · −··"; tt = iw - 1.5
            for c in m:
                if c == "·": put(sfx, tt, beep(780, 0.07), 0.08); tt += 0.12
                elif c == "−": put(sfx, tt, beep(780, 0.2), 0.08); tt += 0.26
                else: tt += 0.15
                if tt > iw + 2.5: break
            put(sfx, iw, thud(1.3), 0.35)
    if sh["type"] == "stack":
        for k in sh["wt"]: put(sfx, k - 0.15, air_whoosh(0.35), 0.12); put(sfx, k + 0.18, thud(), 0.3)
        for k in range(30): put(sfx, sh["wt"][0] + k * 0.04, tick(), 0.07)
        for k in range(40): put(sfx, sh["wt"][1] + k * 0.04, tick(), 0.07)
    if sh["type"] == "end": put(sfx, t0 - 0.6, air_whoosh(1.2), 0.15)
# room tone / wind under everything
x = T(TOTAL); wind = lp(rng.standard_normal(len(x)), 350) * (0.6 + 0.4 * np.sin(2 * np.pi * 0.07 * x)); put(amb, 0, wind, 0.03)

# ---------- mix ----------
vo, vsr = sf.read(f"vo_{name}.wav", dtype="float64"); vo = resample_poly(vo, SR, vsr) if vsr != SR else vo
vo = np.pad(vo, (0, max(0, N - len(vo))))[:N]; vo = hp(vo, 75); vo = vo + 0.15 * bp(vo, 2500, 6000); vo = np.tanh(vo * 1.5) / np.tanh(1.5)
e = np.convolve(np.abs(vo), np.ones(2400) / 2400, "same"); e = np.minimum(1, e / (np.percentile(e[e > 1e-4], 70) + 1e-9))
dk = np.zeros_like(e); a = 0.0
for i in range(0, len(e), 48): a += ((1 - np.exp(-1 / (0.03 * SR))) if e[i] > a else (1 - np.exp(-1 / (0.4 * SR)))) * 48 * (e[i] - a); dk[i:i + 48] = min(1, max(0, a))
duck = 1 - 0.55 * dk
music = reverb(music, 3.0, 0.35); sfx = reverb(sfx, 1.6, 0.2)
bg = (music * 0.55 + amb * 0.6) * duck[:, None] + sfx * 0.5
mix = bg + np.stack([vo, vo], 1)
ft = np.arange(N) / SR; mix *= np.clip((TOTAL - ft) / 1.0, 0, 1)[:, None]
L = int(TOTAL * SR); pk = np.max(np.abs(mix[:L])); mix = mix[:L] / pk * 0.89
sf.write(f"mix_{name}.wav", mix.astype(np.float32), SR)
sp = np.zeros(L, bool)
for s in SC: sp[int(s["start"] * SR):int(s["end"] * SR)] = True
db = lambda z: 20 * np.log10(np.sqrt(np.mean(z ** 2)) + 1e-12)
print(name, "voice", round(db(vo[:L][sp] / pk * .89), 1), "bg under speech", round(db(bg[:L].mean(1)[sp] / pk * .89), 1), "bg gaps", round(db(bg[:L].mean(1)[~sp] / pk * .89), 1))
