const { chromium } = require('playwright');
// node cap.js stills  |  node cap.js gif <shot> <secs> <fps> <outdir>
(async()=>{const [mode,shot,secs,fps,out]=process.argv.slice(2);
const b=await chromium.launch({args:['--force-color-profile=srgb']});const p=await b.newPage({viewport:{width:1080,height:1920}});
p.on('pageerror',e=>console.error('ERR',e.message));
await p.goto('file://'+__dirname+'/samples.html');await p.evaluate(()=>document.fonts.ready);
if(mode==='stills'){for(let n=1;n<=6;n++){await p.evaluate(n=>show(n,4),n);await p.screenshot({path:`stills/still_${n}.png`})}}
else{const N=Math.round(+secs*+fps);for(let i=0;i<N;i++){await p.evaluate(([n,t])=>show(n,t),[+shot,i/+fps]);await p.screenshot({path:`${out}/f${String(i).padStart(4,'0')}.png`})}}
await b.close()})();
