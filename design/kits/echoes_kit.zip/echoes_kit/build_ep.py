"""Build an episode: TTS per line (cached) -> word timings -> shot timeline -> ep_<name>.js + vo_<name>.wav"""
import sys, os, re, json, hashlib, numpy as np, soundfile as sf
from episodes import EPISODES
name = sys.argv[1]; E = EPISODES[name]
voice = os.environ.get("VOICE", E["voice"]); lang = "en-us" if voice[0] == "a" else E["lang"]
os.makedirs("vo", exist_ok=True)
LEAD, GAP, TAIL = 0.7, 0.55, 2.6
kok = None
durs = []
for line in E["lines"]:
    h = hashlib.md5(f"{voice}|{E['speed']}|{line}".encode()).hexdigest()[:12]; f = f"vo/{h}.wav"
    if not os.path.exists(f):
        if kok is None:
            from kokoro_onnx import Kokoro
            kok = Kokoro("../cdn/voice/kokoro-v1.0.onnx", "../cdn/voice/voices-v1.0.bin")
        a, sr = kok.create(line, voice=voice, speed=E["speed"], lang=lang)
        idx = np.where(np.abs(a) > 0.01)[0]; a = a[max(0, idx[0] - 720): idx[-1] + 1900]
        sf.write(f, a, sr)
    a, sr = sf.read(f, dtype="float32"); durs.append((f, a, sr))
scenes, t = [], LEAD
for (f, a, sr), line in zip(durs, E["lines"]):
    d = len(a) / sr; words = line.split(); w = []
    for x in words:
        p = 7 if x.endswith("...") else 4.5 if x[-1] in ".?!" else 2.5 if x[-1] in ",;:" else 0
        w.append((len(re.sub(r"[^\w']", "", x)) + 1.6, p))
    k = d / sum(a_ + b for a_, b in w); cur = t; ws = []
    for x, (a_, b) in zip(words, w):
        ws.append({"w": x, "t0": round(cur, 3), "t1": round(cur + a_ * k, 3)}); cur += (a_ + b) * k
    scenes.append({"start": round(t, 3), "end": round(t + d, 3), "words": ws}); t += d + GAP + E.get("pause_after", {}).get(len(scenes) - 1, 0)
total = round(t - GAP + TAIL, 3)

def W(li, key):
    key, _, n = key.partition("#"); n = int(n or 0)
    hits = [x for x in scenes[li]["words"] if re.sub(r"[^\w']", "", x["w"]).lower().startswith(key.lower())]
    return hits[n]["t0"]
shots = []
for s in E["shots"]:
    t0 = scenes[s["line"]]["start"] - 0.35 if s["at"] == "start" else W(s["line"], s["at"]) - 0.25
    if s["line"] == 0 and s["at"] == "start": t0 = 0
    sh = dict(s); sh["t0"] = round(t0, 3)
    if "words" in s: sh["wt"] = [W(s["line"], k) for k in s["words"]]
    shots.append(sh)
for i, sh in enumerate(shots): sh["t1"] = round(shots[i + 1]["t0"] + 0.7 if i + 1 < len(shots) else total, 3)
EP = {"name": name, "title": E["title"], "keys": E["keys"], "total": total, "scenes": scenes, "shots": shots}
open(f"ep_{name}.js", "w").write("window.EP=" + json.dumps(EP) + ";")
SR = durs[0][2]; vo = np.zeros(int(total * SR) + SR, np.float32)
for sc, (f, a, sr) in zip(scenes, durs): s0 = int(sc["start"] * SR); vo[s0:s0 + len(a)] += a
sf.write(f"vo_{name}.wav", vo[: int(total * SR)], SR)
json.dump(EP, open(f"ep_{name}.json", "w"), indent=1)
print(name, voice, "total", total); [print(f"  {s['type']:5} {s.get('img', s.get('n', ''))!s:16} {s['t0']:6.2f} → {s['t1']:6.2f}") for s in shots]
