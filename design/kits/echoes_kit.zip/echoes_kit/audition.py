import soundfile as sf, numpy as np
from kokoro_onnx import Kokoro
k = Kokoro("../cdn/voice/kokoro-v1.0.onnx", "../cdn/voice/voices-v1.0.bin")
line = "In 1631, an emperor lost the woman he loved... so he built her the most beautiful tomb on Earth."
print([v for v in k.get_voices() if v[:2] in ("bm","am","bf")])
for v in ["bm_george","bm_fable","bm_lewis","am_onyx","am_michael","bf_emma"]:
    try:
        a, sr = k.create(line, voice=v, speed=0.95, lang="en-gb" if v.startswith("b") else "en-us")
        sf.write(f"aud_{v}.wav", a, sr); print(v, round(len(a)/sr,2))
    except Exception as e: print(v, "ERR", e)
