const { chromium } = require('playwright');
(async()=>{const [html,times,out]=process.argv.slice(2);const b=await chromium.launch({args:['--force-color-profile=srgb']});const p=await b.newPage({viewport:{width:1080,height:1920}});
p.on('pageerror',e=>console.error('ERR',e.message));p.on('console',m=>{if(m.type()==='error')console.error('CONSOLE',m.text())});
await p.goto('file://'+__dirname+'/'+html);await p.evaluate(()=>document.fonts.ready);await p.waitForTimeout(300);
for(const t of times.split(',')){await p.evaluate(t=>render(+t),t);await p.waitForTimeout(30);await p.screenshot({path:`${out}/t_${String(t).padStart(5,'0')}.png`})}await b.close()})();
