const { chromium } = require('playwright');
(async()=>{const [html,fps,a,b,out]=process.argv.slice(2);const br=await chromium.launch({args:['--force-color-profile=srgb']});const p=await br.newPage({viewport:{width:1080,height:1920}});
p.on('pageerror',e=>console.error('ERR',e.message));await p.goto('file://'+__dirname+'/'+html);await p.evaluate(()=>document.fonts.ready);await p.waitForTimeout(500);
for(let i=+a;i<+b;i++){await p.evaluate(t=>render(t),i/+fps);await p.screenshot({path:`${out}/f${String(i).padStart(5,'0')}.png`})}await br.close()})();
