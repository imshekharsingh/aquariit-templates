"""Episode definitions for ECHOES · True Stories (hybrid: archival + illustrated).
Shot `at`: "start" = beginning of the line, or a word key (first word in that line starting with it; "word#n" for nth)."""

EPISODES = {
 "taj": {
  "title": "The Prisoner and the Tomb",
  "voice": "bm_george", "lang": "en-gb", "speed": 0.98,
  "pause_after": {2: 1.6},
  "keys": ["1631", "1658", "fourteenth", "beautiful", "Twenty", "son", "Agra", "eight", "side", "only", "symmetry", "ECHOES"],
  "lines": [
   "In 1631, an emperor lost the woman he loved.",
   "Mumtaz Mahal died giving birth to their fourteenth child.",
   "So Shah Jahan built her the most beautiful tomb on Earth. Twenty thousand artisans. Twenty-two years.",
   "But in 1658, his own son seized the throne... and locked him inside Agra Fort.",
   "Legend says that for eight years, he gazed at her tomb across the river.",
   "Today they lie side by side. And his tomb is the only thing in the Taj Mahal that breaks its perfect symmetry.",
   "Echoes. True stories, carved in stone.",
  ],
  "shots": [
   {"line": 0, "at": "start", "type": "arch", "img": "shah_jahan", "mode": "framed", "stamp": ["BURHANPUR · 1631", "1631"]},
   {"line": 1, "at": "start", "type": "ill", "n": 2},
   {"line": 2, "at": "start", "type": "ill", "n": 4},
   {"line": 2, "at": "years", "type": "arch", "img": "taj_bourne", "mode": "full", "develop": True},
   {"line": 3, "at": "start", "type": "arch", "img": "father_son", "mode": "framed", "stamp": ["AGRA · 1658", "1658"]},
   {"line": 3, "at": "seized", "type": "arch", "img": "aurangzeb", "mode": "framed"},
   {"line": 4, "at": "start", "type": "ill", "n": 5, "img": "taj_bourne"},
   {"line": 5, "at": "start", "type": "arch", "img": "cenotaphs", "mode": "full"},
   {"line": 5, "at": "only", "type": "ill", "n": 6, "img": "cenotaphs"},
   {"line": 6, "at": "start", "type": "end"},
  ],
 },
 "eiffel": {
  "title": "The Tower Paris Wanted Gone",
  "voice": "bm_george", "lang": "en-gb", "speed": 0.98,
  "keys": ["1887", "protest", "useless", "monstrous", "anyway", "Eighteen", "million", "twenty", "1909", "useful", "antenna", "intercepted", "invisible", "ECHOES"],
  "lines": [
   "In 1887, the most famous artists in Paris signed a protest... against a useless and monstrous tower.",
   "Gustave Eiffel built it anyway. Eighteen thousand iron parts. Two and a half million rivets. In just over two years.",
   "But it was only allowed to stand for twenty years. In 1909, its permit would run out.",
   "So Eiffel made it useful. He turned it into a laboratory... and a giant radio antenna.",
   "In World War One, that antenna intercepted enemy radio messages.",
   "The tower Paris wanted gone... was saved by the invisible waves it carried.",
   "Echoes. True stories, carved in stone.",
  ],
  "shots": [
   {"line": 0, "at": "start", "type": "ill", "n": 10},
   {"line": 1, "at": "start", "type": "arch", "img": "eiffel_portrait", "mode": "framed"},
   {"line": 1, "at": "Eighteen", "type": "stack", "imgs": ["build_1", "build_2", "build_3", "build_4"], "words": ["Eighteen", "Two", "million", "over"]},
   {"line": 2, "at": "start", "type": "ill", "n": 12},
   {"line": 3, "at": "start", "type": "arch", "img": "tower_1889", "mode": "full", "develop": True},
   {"line": 3, "at": "giant", "type": "ill", "n": 13},
   {"line": 4, "at": "start", "type": "arch", "img": "wireless_1914", "mode": "framed", "stamp": ["WIRELESS STATION · 1914", "1914"]},
   {"line": 4, "at": "intercepted", "type": "ill", "n": 13},
   {"line": 5, "at": "start", "type": "arch", "img": "tower_night", "mode": "full", "waves": True},
   {"line": 6, "at": "start", "type": "end"},
  ],
 },
}
