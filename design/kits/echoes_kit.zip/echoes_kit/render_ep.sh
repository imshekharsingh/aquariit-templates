#!/bin/bash
# render_ep.sh <ep> <workers>
cd "$(dirname "$0")"; E=$1; P=${2:-2}; export NODE_PATH=/opt/node22/lib/node_modules
./mk.sh $E >/dev/null && python3 sound_h.py $E
TOTAL=$(python3 -c "import json;print(json.load(open('ep_$E.json'))['total'])"); N=$(python3 -c "import math;print(math.ceil($TOTAL*60))")
mkdir -p fr_$E; C=$(((N+P-1)/P))
for i in $(seq 0 $((P-1))); do S=$((i*C)); En=$(((i+1)*C)); [ $En -gt $N ] && En=$N; node capf.js ep_$E.html 60 $S $En fr_$E & done; wait
mkdir -p /home/user/history_samples
ffmpeg -loglevel error -y -framerate 60 -i fr_$E/f%05d.png -i mix_$E.wav -vf "tmix=frames=2:weights='1 1',fps=30,format=yuv420p" -map 0:v -map 1:a -shortest \
  -c:v libx264 -profile:v high -level 4.2 -preset slow -crf 17 -g 60 -c:a aac -b:a 192k -ar 48000 -movflags +faststart /home/user/history_samples/echoes_$E.mp4
ffmpeg -loglevel error -y -i /home/user/history_samples/echoes_$E.mp4 -vf "select='not(mod(n\,90))',scale=216:-1,tile=17x1" -frames:v 1 sheet_$E.png
echo DONE $E
