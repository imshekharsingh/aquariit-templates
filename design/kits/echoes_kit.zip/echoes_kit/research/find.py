import json, sys, time, urllib.request, urllib.parse, html, re
UA = {"User-Agent": "EchoesHistoryShorts/0.1 (educational video research; https://claude.ai)"}
def api(params):
    url = "https://en.wikipedia.org/w/api.php?" + urllib.parse.urlencode({**params, "format": "json", "formatversion": 2})
    import subprocess
    for i in range(6):
        time.sleep(4)
        r = subprocess.run(["curl", "-s", "-w", "\n%{http_code}", "-A", UA["User-Agent"], url], capture_output=True, text=True)
        body, code = r.stdout.rsplit("\n", 1)
        if code == "200": return json.loads(body)
        time.sleep(10 * (i + 1))
    raise RuntimeError("rate limited: " + url)
out = {}
for art in sys.argv[1:]:
    files = [i["title"] for i in api({"action": "query", "titles": art, "prop": "images", "imlimit": 200})["query"]["pages"][0].get("images", [])]
    files = [f for f in files if re.search(r"\.(jpe?g|png|tif)$", f, re.I)]
    for k in range(0, len(files), 40):
        q = api({"action": "query", "titles": "|".join(files[k:k+40]), "prop": "imageinfo", "iiprop": "url|size|extmetadata", "iiurlwidth": 1600})
        for p in q["query"]["pages"]:
            ii = (p.get("imageinfo") or [{}])[0]; m = ii.get("extmetadata", {})
            g = lambda x: re.sub("<[^>]+>", "", html.unescape(m.get(x, {}).get("value", "")))[:140]
            out[p["title"]] = {"art": art, "lic": g("LicenseShortName"), "artist": g("Artist"), "date": g("DateTimeOriginal"), "desc": g("ImageDescription")[:140], "w": ii.get("width"), "h": ii.get("height"), "thumb": ii.get("thumburl"), "page": ii.get("descriptionurl")}
        time.sleep(1)
import os
old = json.load(open("research/cands.json")) if os.path.exists("research/cands.json") else {}
old.update(out); out = old
json.dump(out, open("research/cands.json", "w"), indent=1)
for t, v in out.items():
    if "public domain" in v["lic"].lower() or v["lic"].upper().startswith("PD") or v["lic"].lower().startswith("cc0"):
        print(f"{v['art'][:12]:12} | {t[5:70]:65} | {v['lic'][:14]:14} | {v['date'][:20]:20} | {v['w']}x{v['h']}")
