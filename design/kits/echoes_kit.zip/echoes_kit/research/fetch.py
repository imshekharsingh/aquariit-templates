import json, re, html, subprocess, time, urllib.parse, os
UA = "EchoesHistoryShorts/0.1 (educational video research; https://claude.ai)"
def full(prefix, ml):
    d = json.load(open(ml)); return next(i["title"] for i in d["items"] if i["title"][5:].startswith(prefix))
WANT = {  # key: (file title, display title)
 "shah_jahan": ("File:Shahjahan_on_globe,_mid_17th_century.jpg", "Shah Jahan on a globe · Hashim, c. 1630s"),
 "father_son": (full("Shah_Jahan_and_Aurangzeb", "research/ml2_Aurangzeb.json"), "Shah Jahan and Aurangzeb · c. 1659"),
 "aurangzeb": (full("Aurangzeb_enthroned_in_a_darbar", "research/ml2_Aurangzeb.json"), "Aurangzeb enthroned"),
 "taj_bourne": ("File:Sambourneagra1860s.jpg", "The Taj Mahal · Samuel Bourne, 1860s"),
 "taj_1914": ("File:Taj_Mahal_1921.JPG", "The Taj Mahal · Autochrome, 1914"),
 "cenotaphs": ("File:Interior_of_Taj,_Agra_(cropped).jpg", "Interior of the Taj · Raphael Tuck & Sons, 1905"),
 "eiffel_portrait": ("File:Gustave_Eiffel_1888_Nadar2.jpg", "Gustave Eiffel · Nadar, 1888"),
 "build_1": ("File:Construction_tour_eiffel2.JPG", "DEC 1887"),
 "build_2": ("File:Construction_tour_eiffel4.JPG", "1888"),
 "build_3": ("File:Construction_tour_eiffel6.JPG", "1888"),
 "build_4": ("File:Construction_tour_eiffel7.JPG", "MARCH 1889"),
 "tower_1889": ("File:Exposition_Universelle_de_Paris_1889_-_Universitäts-_und_Landesbibliothek_Darmstadt.jpg", "World's Fair, Paris · 1889"),
 "tower_1889b": ("File:Lightning_striking_the_Eiffel_Tower_-_NOAA.jpg", "Lightning strikes the tower · G. Loppé, 1902"),
}
import hashlib
cache = {}
for p in json.load(open("research/ii_batch.json"))["query"]["pages"]: cache[p["title"].replace(" ", "_")] = p
need = [v[0] for v in WANT.values() if v[0].replace(" ", "_") not in cache]
titles = "|".join(need)
url = "https://en.wikipedia.org/w/api.php?" + urllib.parse.urlencode({"action": "query", "format": "json", "formatversion": 2, "prop": "imageinfo", "iiprop": "url|size|extmetadata", "iiurlwidth": 1800, "titles": titles})
for i in range(3):
    time.sleep(20 + 20 * i); r = subprocess.run(["curl", "-s", "-w", "\n%{http_code}", "-A", UA, url], capture_output=True, text=True); body, code = r.stdout.rsplit("\n", 1)
    if code == "200": break
d = json.loads(body) if code == "200" else {"query": {"pages": []}}
if code == "200": json.dump(d, open("research/ii_new.json", "w"))
norm = {n["to"]: n["from"] for n in d["query"].get("normalized", [])}
by = dict(cache)
for p in d["query"]["pages"]:
    by[norm.get(p["title"], p["title"]).replace(" ", "_")] = p; by[p["title"].replace(" ", "_")] = p
meta = {}
for k, (ft, disp) in WANT.items():
    p = by.get(ft.replace(" ", "_"))
    name = ft[5:].replace(" ", "_"); h5 = hashlib.md5(name.encode()).hexdigest(); q = urllib.parse.quote(name)
    if p is None: p = {"imageinfo": [{"width": 0, "url": f"https://upload.wikimedia.org/wikipedia/commons/{h5[0]}/{h5[:2]}/{q}", "descriptionurl": f"https://commons.wikimedia.org/wiki/File:{q}", "extmetadata": {"LicenseShortName": {"value": "UNVERIFIED"}}}]}
    ii = p["imageinfo"][0]; m = ii.get("extmetadata", {})
    g = lambda x: re.sub("<[^>]+>", "", html.unescape(m.get(x, {}).get("value", ""))).strip()
    lic = g("LicenseShortName"); src = f"https://upload.wikimedia.org/wikipedia/commons/thumb/{h5[0]}/{h5[:2]}/{q}/1920px-{q}" if ii["width"] > 1920 else f"https://upload.wikimedia.org/wikipedia/commons/{h5[0]}/{h5[:2]}/{q}"
    out = f"images/{k}.jpg"
    alts = [src] if ii["width"] else [f"https://upload.wikimedia.org/wikipedia/commons/thumb/{h5[0]}/{h5[:2]}/{q}/1920px-{q}", f"https://upload.wikimedia.org/wikipedia/commons/{h5[0]}/{h5[:2]}/{q}"]
    if not os.path.exists(out):
        ok = False
        for s_ in alts:
            for i in range(4):
                time.sleep(12 + 15 * i); r = subprocess.run(["curl", "-s", "-L", "-o", out + ".tmp", "-w", "%{http_code}", "-A", UA, s_], capture_output=True, text=True)
                if r.stdout == "200": ok = True; break
                if r.stdout in ("400", "404"): break
            if ok: break
        if not ok: print(k, "DOWNLOAD FAILED", r.stdout); continue
        subprocess.run(["ffmpeg", "-loglevel", "error", "-y", "-i", out + ".tmp", "-vf", "scale='min(1800,iw)':-2", "-q:v", "2", out]); os.remove(out + ".tmp")
    w, h = map(int, subprocess.run(["ffprobe", "-v", "error", "-show_entries", "stream=width,height", "-of", "csv=p=0", out], capture_output=True, text=True).stdout.strip().split(","))
    credit = ("PUBLIC DOMAIN" if "public domain" in lic.lower() or lic.upper().startswith("PD") else lic.upper()) + " · WIKIMEDIA COMMONS"
    meta[k] = {"src": f"images/{k}.jpg", "w": w, "h": h, "title": disp, "credit": credit, "license": lic, "artist": g("Artist")[:80], "page": ii["descriptionurl"],
               "mono": k in ("taj_bourne", "eiffel_portrait", "build_1", "build_2", "build_3", "build_4", "tower_1889", "tower_1889b", "cenotaphs")}
    print(f"{k:16} {lic:16} {w}x{h}")
open("images/manifest.js", "w").write("window.IMG=" + json.dumps(meta) + ";")
json.dump(meta, open("images/manifest.json", "w"), indent=1)
