import json, re, numpy as np, soundfile as sf
meta = json.load(open("vo.json"))
LEAD, GAP, TAIL = 0.6, 0.45, 2.2
SR = meta[0]["sr"]
scenes, t = [], LEAD
for m in meta:
    words = m["text"].split()
    # estimate word timings: weight = chars, plus pauses after punctuation
    w = []
    for x in words:
        p = 0
        if x.endswith("..."): p = 7
        elif x[-1] in ".?!": p = 4.5
        elif x[-1] in ",;:": p = 2.5
        w.append((len(re.sub(r"[^\w']", "", x)) + 1.6, p))
    tot = sum(a + b for a, b in w)
    k = m["dur"] / tot
    cur, ws = t, []
    for x, (a, b) in zip(words, w):
        ws.append({"w": x, "t0": round(cur, 3), "t1": round(cur + a * k, 3)})
        cur += (a + b) * k
    scenes.append({"start": round(t, 3), "end": round(t + m["dur"], 3), "words": ws})
    t += m["dur"] + GAP
total = round(t - GAP + TAIL, 3)

def W(si, key, n=0):
    hits = [x for x in scenes[si]["words"] if re.sub(r"[^\w']", "", x["w"]).lower().startswith(key.lower())]
    return hits[n]["t0"]
S = lambda i: scenes[i]["start"]
cues = {
 "globe_in": 0.15, "pin_tokyo": W(0,"Tokyo"), "pin_ny": W(0,"New"),
 "arc_long": W(1,"travels"), "users": W(1,"Thousands"), "every": W(1,"Every",1), "single": W(1,"Single"), "time": W(1,"Time"),
 "fix": W(2,"content"), "edges": W(2,"copies"), "world": W(2,"world"),
 "hit_req": W(3,"opens"), "hit_ans": W(3,"nearest"), "hit_badge": W(3,"hit"), "hit_ms": W(3,"milliseconds"),
 "miss_req": S(4), "miss_badge": W(4,"miss"), "fetch": W(4,"fetches"), "store": W(4,"stores"), "serve": W(4,"everyone"),
 "spread": W(5,"traffic"), "ddos": W(5,"DDoS"), "absorb": W(5,"absorbs"), "safe": W(5,"reach"),
 "faster": W(6,"Faster"), "lower": W(6,"Lower"), "stronger": W(6,"Stronger"), "final": W(6,"That's"),
}
json.dump({"total": total, "scenes": scenes, "cues": cues}, open("timeline.json", "w"), indent=1)
open("timeline.js", "w").write("window.TL=" + json.dumps({"total": total, "scenes": scenes, "cues": cues}) + ";")
# voice track
vo = np.zeros(int(total * SR) + SR, dtype=np.float32)
for i, sc in enumerate(scenes):
    a, _ = sf.read(f"vo_{i}.wav", dtype="float32"); s = int(sc["start"] * SR); vo[s:s+len(a)] += a
sf.write("vo_full.wav", vo[:int(total*SR)], SR)
print("total", total); print({k: round(v,2) for k,v in cues.items()})
