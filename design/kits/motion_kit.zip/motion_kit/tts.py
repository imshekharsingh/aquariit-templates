import json, soundfile as sf, numpy as np, sys
from kokoro_onnx import Kokoro
k = Kokoro("voice/kokoro-v1.0.onnx", "voice/voices-v1.0.bin")
LINES = [
 "Why does a website load instantly in Tokyo... when its server sits in New York?",
 "Without a CDN, every request travels all the way to one origin server. Thousands of kilometers. Every. Single. Time.",
 "A content delivery network fixes that. It copies your content to edge servers, all around the world.",
 "Now, when someone in Tokyo opens your page, the nearest edge answers. That's a cache hit, in milliseconds.",
 "If the edge doesn't have it yet, that's a cache miss. It fetches once from the origin, stores it, and serves everyone after.",
 "And because traffic is spread across the edge, a CDN absorbs DDoS attacks before they ever reach your server.",
 "Faster pages. Lower load. Stronger security. That's a CDN.",
]
voice = sys.argv[1] if len(sys.argv) > 1 else "af_heart"
meta = []
for i, line in enumerate(LINES):
    a, sr = k.create(line, voice=voice, speed=1.05, lang="en-us")
    # trim leading/trailing silence
    idx = np.where(np.abs(a) > 0.01)[0]
    a = a[max(0, idx[0]-int(.03*sr)): idx[-1]+int(.08*sr)]
    sf.write(f"vo_{i}.wav", a, sr)
    meta.append({"i": i, "text": line, "dur": len(a)/sr, "sr": sr})
    print(i, round(len(a)/sr, 2))
json.dump(meta, open("vo.json", "w"), indent=1)
