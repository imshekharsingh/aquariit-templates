const { chromium } = require('playwright');
const path = require('path');
// usage: node capture.js <outdir> <fps> <start> <end>   OR  node capture.js <outdir> times t1,t2,...
(async () => {
  const [outdir, mode, a, b] = process.argv.slice(2);
  const browser = await chromium.launch({ args: ['--force-color-profile=srgb', '--hide-scrollbars'] });
  const page = await browser.newPage({ viewport: { width: +(process.env.W||1920), height: +(process.env.H||1080) } });
  page.on('pageerror', e => console.error('PAGEERR', e.message));
  await page.goto('file://' + path.resolve(__dirname, process.env.SCENE||'scene.html'));
  await page.evaluate(() => document.fonts.ready);
  let jobs = [];
  if (mode === 'times') jobs = a.split(',').map(t => [`t_${t}`, +t]);
  else { const fps = +mode; for (let i = +a; i < +b; i++) jobs.push([`f${String(i).padStart(5, '0')}`, i / fps]); }
  const t0 = Date.now();
  for (const [name, t] of jobs) {
    await page.evaluate(t => window.render(t), t);
    await page.screenshot({ path: path.join(outdir, name + '.png') });
  }
  console.error(`done ${jobs.length} in ${(Date.now() - t0) / 1000}s`);
  await browser.close();
})();
