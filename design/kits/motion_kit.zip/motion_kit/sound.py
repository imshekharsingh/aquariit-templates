"""Original music bed + sound design for the CDN explainer, synced to timeline.json cues."""
import json, numpy as np, soundfile as sf
from scipy.signal import butter, sosfilt, fftconvolve

SR = 48000
TL = json.load(open("timeline.json"))
C, SC, TOTAL = TL["cues"], TL["scenes"], TL["total"]
st = lambda i: SC[i]["start"]
en = lambda i: SC[i]["end"]
N = int(TOTAL * SR) + SR
rng = np.random.default_rng(7)

def T(d): return np.arange(int(d * SR)) / SR
def lp(x, f, o=2): return sosfilt(butter(o, f, "low", fs=SR, output="sos"), x)
def hp(x, f, o=2): return sosfilt(butter(o, f, "high", fs=SR, output="sos"), x)
def bp(x, lo, hi, o=2): return sosfilt(butter(o, [lo, hi], "band", fs=SR, output="sos"), x)
def put(bus, t0, sig, gain=1.0, pan=0.0):
    s = int(t0 * SR)
    if s >= N or s + len(sig) <= 0: return
    if s < 0: sig, s = sig[-s:], 0
    sig = sig[: N - s]
    l, r = np.cos((pan + 1) * np.pi / 4), np.sin((pan + 1) * np.pi / 4)
    bus[s:s + len(sig), 0] += sig * gain * l * 1.414
    bus[s:s + len(sig), 1] += sig * gain * r * 1.414
def env(n, a, d):  # attack/exp-decay envelope
    t = np.arange(n) / SR
    e = np.minimum(1, t / max(a, 1e-4)) * np.exp(-np.maximum(0, t - a) / d)
    return e
def reverb(x, secs=1.6, mix=0.25):
    n = int(secs * SR); t = np.arange(n) / SR
    ir = rng.standard_normal((n, 2)) * np.exp(-t / (secs / 5))[:, None]
    ir[:, 0] = lp(ir[:, 0], 6000); ir[:, 1] = lp(ir[:, 1], 6000)
    wet = np.stack([fftconvolve(x[:, c], ir[:, c])[: len(x)] for c in range(2)], 1)
    wet *= np.max(np.abs(x)) / (np.max(np.abs(wet)) + 1e-9)
    return x * (1 - mix) + wet * mix
def nf(name):  # note -> freq
    names = {"C": -9, "C#": -8, "D": -7, "D#": -6, "E": -5, "F": -4, "F#": -3, "G": -2, "G#": -1, "A": 0, "A#": 1, "B": 2}
    return 440 * 2 ** ((names[name[:-1]] + 12 * (int(name[-1]) - 4)) / 12)

music = np.zeros((N, 2)); drums = np.zeros((N, 2)); sfx = np.zeros((N, 2))

# ---------------- music ----------------
BPM = 100; beat = 60 / BPM; bar = beat * 4
CHORDS = [["A2", "A3", "C4", "E4", "G4"], ["F2", "F3", "A3", "C4", "E4"], ["C3", "G3", "C4", "E4", "G4"], ["G2", "G3", "B3", "D4", "F#4"]]
t_end_music = C["final"]
def saw(f, d, det=0.0):
    t = T(d); y = np.zeros_like(t)
    for h in range(1, 10):
        if f * h > 9000: break
        y += np.sin(2 * np.pi * f * (1 + det) * h * t + h) / h
    return y
cl = 2 * bar
for ci, t0 in enumerate(np.arange(0.3, t_end_music, cl)):
    ch = CHORDS[ci % 4]; d = cl + 0.8
    for k, n in enumerate(ch[1:]):
        f = nf(n)
        for det, pan in ((-0.004, -0.6), (0.004, 0.6)):
            v = lp(saw(f, d, det), 1500) * env(int(d * SR), 0.6, 2.6)
            v *= np.minimum(1, (d - T(d)) / 0.8)
            put(music, t0, v, 0.035, pan)
    # sub/bass root
    fr = nf(ch[0])
    if t0 >= st(1) - 0.1:
        for b in np.arange(0, cl, beat / 2):
            if t0 + b > t_end_music: break
            tt = T(beat / 2 * 0.95); s = np.sin(2 * np.pi * fr * tt) + 0.3 * np.sin(4 * np.pi * fr * tt)
            put(music, t0 + b, s * env(len(tt), 0.005, 0.12), 0.12 if t0 >= st(2) - .2 else 0.06)
    # pluck arp from the fix onward
    if t0 >= st(2) - cl:
        tones = [nf(x) * 2 for x in ch[1:]]
        for j, b in enumerate(np.arange(0, cl, beat / 4)):
            tt = t0 + b
            if tt < st(2) or tt > t_end_music: continue
            f = tones[[0, 2, 1, 3, 2, 1, 3, 2][j % 8]]; x = T(0.35)
            s = (np.sin(2 * np.pi * f * x) + 0.4 * np.sin(4 * np.pi * f * x)) * env(len(x), 0.002, 0.09)
            put(music, tt, s, 0.05, 0.4 * np.sin(j))

# drums
def kick(g=1):
    x = T(0.45); f = 45 + 95 * np.exp(-x / 0.04)
    return (np.sin(2 * np.pi * np.cumsum(f) / SR) * env(len(x), 0.002, 0.16) + 0.3 * lp(rng.standard_normal(len(x)), 900) * env(len(x), 0.001, 0.01)) * g
def hat():
    x = T(0.08); return hp(rng.standard_normal(len(x)), 7500) * env(len(x), 0.001, 0.018)
def clap():
    x = T(0.25); return bp(rng.standard_normal(len(x)), 900, 4000) * (env(len(x), 0.001, 0.05) + 0.6 * np.roll(env(len(x), 0.001, 0.03), 480))
grid0 = 0.3
for b in np.arange(grid0, t_end_music - 0.05, beat):
    i = round((b - grid0) / beat)
    if st(1) - .1 <= b < st(2) - .3 and i % 2 == 0: put(drums, b, kick(), 0.32)      # heartbeat tension
    if b >= st(2):
        put(drums, b, kick(), 0.42)
        put(drums, b + beat / 2, hat(), 0.10, 0.3)
        if i % 2 == 1: put(drums, b, clap(), 0.07, -0.1)
    if b >= st(3): put(drums, b + beat / 4 * 3, hat(), 0.05, -0.3)

# ---------------- SFX ----------------
def whoosh(d=0.7, up=True, g=1.0):
    n = int(d * SR); x = rng.standard_normal(n); y = np.zeros(n); a = 0.0
    fc = np.linspace(300, 6000, n) if up else np.linspace(6000, 300, n)
    alpha = 1 - np.exp(-2 * np.pi * fc / SR)
    for i in range(n): a += alpha[i] * (x[i] - a); y[i] = a
    e = np.sin(np.pi * np.linspace(0, 1, n)) ** 2
    return y * e * g
def blip(f, d=0.25, f2=None, g=1.0, harm=0.3):
    x = T(d); ff = np.full_like(x, f) if f2 is None else f + (f2 - f) * (1 - np.exp(-x / 0.05))
    ph = 2 * np.pi * np.cumsum(ff) / SR
    return (np.sin(ph) + harm * np.sin(2 * ph)) * env(len(x), 0.003, d / 4) * g
def chime(fs, d=1.4, g=1.0):
    x = T(d); y = np.zeros_like(x)
    for k, f in enumerate(fs):
        y += np.roll((np.sin(2 * np.pi * f * x) + 0.25 * np.sin(2 * np.pi * f * 2.76 * x) * np.exp(-x / 0.1)) * env(len(x), 0.002, d / 3.5), int(k * 0.06 * SR))
    return y * g / len(fs)
def impact(g=1.0):
    x = T(2.2); f = 32 + 70 * np.exp(-x / 0.08)
    body = np.sin(2 * np.pi * np.cumsum(f) / SR) * env(len(x), 0.003, 0.5)
    noise = lp(rng.standard_normal(len(x)), 2500) * env(len(x), 0.002, 0.25) * 0.5
    return (body + noise) * g
def riser(d=1.2, g=1.0):
    n = int(d * SR); x = T(d); f = 200 * 2 ** (x / d * 3)
    tone = np.sin(2 * np.pi * np.cumsum(f) / SR) * 0.3
    return (hp(rng.standard_normal(n), 1500) * 0.6 + tone) * (x / d) ** 2.5 * g
def zap(g=1.0):
    x = T(0.12); return (hp(rng.standard_normal(len(x)), 2000) * 0.6 + np.sin(2 * np.pi * (1800 - 9000 * x) * x)) * env(len(x), 0.001, 0.025) * g
def thud(g=1.0):
    k = kick(1.4); n = len(k)
    return (k + 0.5 * lp(rng.standard_normal(n), 400) * env(n, 0.001, 0.08)) * g
    return (kick(1.4)[: int(0.5 * SR)] + 0.5 * lp(rng.standard_normal(int(0.5 * SR)), 400) * env(int(0.5 * SR), 0.001, 0.08)) * g

# hook
put(sfx, 0.35, impact(), 0.55)
put(sfx, 0.15, whoosh(1.0, False), 0.25)
put(sfx, C["pin_tokyo"], blip(880, 0.35, 1320), 0.25, -0.5)
put(sfx, C["pin_ny"], blip(660, 0.35, 990), 0.25, 0.5)
# scene transitions
for i in range(1, 7): put(sfx, st(i) - 0.45, whoosh(0.75, True), 0.22, (-1) ** i * 0.3)
put(sfx, st(2) - 1.3, riser(1.2), 0.22)
# problem
put(sfx, C["arc_long"], whoosh(1.2, True), 0.15, 0.4)
tk = C["arc_long"] + 0.3
while tk < C["time"] + 0.3:
    put(sfx, tk, blip(2400, 0.03, harm=0), 0.05, 0.2); tk += 0.09
for i in range(5): put(sfx, C["users"] + i * 0.22, blip(520 - i * 30, 0.2, 380), 0.12, -0.6 + i * 0.3)
for k in ("every", "single", "time"): put(sfx, C[k], thud(), 0.6)
# fix: edges come online (ascending pentatonic pings)
pent = [nf(n) for n in ["A5", "C6", "D6", "E6", "G6", "A6", "C7", "D7", "E7", "G7", "A7"]]
for i in range(11):
    t0 = C["edges"] + i * 0.29
    put(sfx, t0 - 0.9, whoosh(0.5, True), 0.05, -0.8 + i * 0.16)
    put(sfx, t0, blip(pent[i] / 2, 0.5, harm=0.15), 0.14, -0.8 + i * 0.16)
# cache hit
put(sfx, C["hit_req"], blip(700, 0.25, 1400), 0.18, -0.3)
put(sfx, C["hit_ans"], chime([nf("E6"), nf("G#6"), nf("B6")], 1.2), 0.32, 0.2)
put(sfx, C["hit_badge"], blip(1320, 0.3, 1760), 0.15)
x = C["hit_badge"] - 0.3
while x < C["hit_ms"] + 0.6: put(sfx, x, blip(3000, 0.02, harm=0), 0.035); x += 0.06
# cache miss
put(sfx, st(4) + 0.9, blip(700, 0.25, 1400), 0.16, -0.4)
put(sfx, C["miss_badge"], blip(440, 0.18), 0.22); put(sfx, C["miss_badge"] + 0.14, blip(330, 0.3), 0.22)
put(sfx, C["fetch"], whoosh(0.8, True), 0.22, 0.5)
put(sfx, C["fetch"] + 0.75, blip(990, 0.2), 0.12, 0.6)
put(sfx, C["fetch"] + 0.8, whoosh(0.8, False), 0.18, -0.2)
put(sfx, C["store"], blip(180, 0.12, harm=0.8), 0.35); put(sfx, C["store"] + 0.05, chime([nf("A5"), nf("E6")], 0.9), 0.22)
for i in range(4): put(sfx, C["serve"] - 0.35 + i * 0.16 + 0.55, blip(pent[3 + i], 0.25), 0.15, -0.6 + i * 0.4)
# ddos: alarm, swarm zaps, shield hum, safe chime
for k in range(3): put(sfx, C["spread"] + 0.6 + k * 0.42, blip(880, 0.18, 620, harm=0.6), 0.12, 0.3)
def mulberry(a):
    s = [a & 0xFFFFFFFF]
    def r():
        s[0] = (s[0] + 0x6D2B79F5) & 0xFFFFFFFF; a_ = s[0]
        t = ((a_ ^ (a_ >> 15)) * (1 | a_)) & 0xFFFFFFFF
        t = ((t + (((t ^ (t >> 7)) * (61 | t)) & 0xFFFFFFFF)) & 0xFFFFFFFF) ^ t
        return ((t ^ (t >> 14)) & 0xFFFFFFFF) / 4294967296
    return r
PR = mulberry(9)
for _ in range(90):
    t0 = C["absorb"] - .7 + PR() * 3.4; ang = PR(); PR(); PR(); dur = .55 + PR() * .35
    put(sfx, t0 + dur, zap(), 0.07, np.cos(ang * 2 * np.pi) * 0.7)
x = T(2.2); hum = (np.sin(2 * np.pi * 110 * x) + 0.5 * np.sin(2 * np.pi * 220.7 * x) + 0.25 * np.sin(2 * np.pi * 441 * x)) * (0.6 + 0.4 * np.sin(2 * np.pi * 7 * x))
put(sfx, C["absorb"] - 0.3, hum * np.minimum(1, x / 0.3) * np.minimum(1, (2.2 - x) / 0.8), 0.07)
put(sfx, C["safe"], chime([nf("C6"), nf("E6"), nf("G6"), nf("C7")], 1.6), 0.32)
# recap pops
for k, f in (("faster", nf("A5")), ("lower", nf("C#6")), ("stronger", nf("E6"))):
    put(sfx, C[k], blip(f, 0.4, harm=0.2), 0.2); put(sfx, C[k] - 0.12, whoosh(0.3, True), 0.08)
# final
put(sfx, C["final"] - 1.25, riser(1.2), 0.2)
put(sfx, C["final"], impact(), 0.6)
put(sfx, C["final"], chime([nf("A4"), nf("C#5"), nf("E5"), nf("B5"), nf("E6")], 3.2), 0.4)
x = T(3.0); pad_end = sum(np.sin(2 * np.pi * nf(n) * x) for n in ["A3", "E4", "C#5", "B4"]) * env(len(x), 0.05, 1.0)
put(music, C["final"], lp(pad_end, 3000), 0.06)

# ---------------- mix ----------------
vo, vsr = sf.read("vo_full.wav", dtype="float64"); assert vsr == 24000 or vsr == SR
if vsr != SR:
    from scipy.signal import resample_poly
    vo = resample_poly(vo, SR, vsr)
vo = np.pad(vo, (0, max(0, N - len(vo))))[:N]
# voice chain: gentle high-pass, presence, compression-ish soft clip
vo = hp(vo, 80); vo = vo + 0.18 * bp(vo, 2500, 6000)
vo = np.tanh(vo * 1.6) / np.tanh(1.6)
vo_st = np.stack([vo, vo], 1)
# duck music under voice
e = np.abs(vo); win = int(0.05 * SR); e = np.convolve(e, np.ones(win) / win, "same")
e = np.minimum(1, e / (np.percentile(e[e > 1e-4], 70) + 1e-9))
dk = np.zeros_like(e); a = 0.0
att, rel = 1 - np.exp(-1 / (0.03 * SR)), 1 - np.exp(-1 / (0.35 * SR))
for i in range(0, len(e), 48):  # block-wise smoothing
    target = e[i]; a += (att if target > a else rel) * 48 * (target - a); dk[i:i + 48] = min(1, max(0, a))
duck = 1 - 0.6 * dk
music = reverb(music, 2.2, 0.3); sfx = reverb(sfx, 1.4, 0.18)
bed = (music + drums * 0.9) * duck[:, None]
mix = bed * 0.34 + sfx * 0.42 + vo_st * 1.0
# fade tail
ft = np.arange(N) / SR; mix *= np.clip((TOTAL - ft) / 0.6, 0, 1)[:, None]
mix = mix[: int(TOTAL * SR)]
mix /= np.max(np.abs(mix)) / 0.89
sf.write("mix.wav", mix.astype(np.float32), SR)
print("ok", mix.shape[0] / SR)
_pk = np.max(np.abs((bed * 0.34 + sfx * 0.42 + vo_st)[: int(TOTAL * SR)]))
np.save("stem_bg.npy", ((bed * 0.34 + sfx * 0.42)[: int(TOTAL * SR)] / _pk * 0.89).mean(1).astype(np.float32))
np.save("stem_vo.npy", (vo[: int(TOTAL * SR)] / _pk * 0.89).astype(np.float32))
