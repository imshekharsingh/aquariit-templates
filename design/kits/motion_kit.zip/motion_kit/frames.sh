#!/bin/bash
cd "$(dirname "$0")"
export NODE_PATH=/opt/node22/lib/node_modules SCENE=scene.html W=1080 H=1920
N=2891; P=4; C=$(((N+P-1)/P))
for i in $(seq 0 $((P-1))); do E=$(((i+1)*C)); [ $E -gt $N ] && E=$N; node capture.js frames 60 $((i*C)) $E 2> log_$i.txt & done
wait; echo FRAMES_DONE
